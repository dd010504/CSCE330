
%For all of these, especially the first two, see the examples in the book
%Ignore the Singleton variable warning, that goes away when you 
% define the rules. 

%europe map coloring problem -- use these colors as the domain
europe_color(Fr,Sw,It,Be,Ho,Ge,Au):-fail.



cryptarithmetic(C,R,O,S,A,D,N,G,E):-fail.



%Persons are just their names, lower case
who_ordered_pizza(PizzaPerson):- fail.
