
% Basic List Processing

% exactly3: True if the list has exactly 3 elements.
% We use anonymous variables (_) to represent the 3 items, and an empty list ([]) for the tail.

exactly3([_, _, _]).


% at_least_3: True if the list has 3 elements, followed by ANY tail.
% The tail can be empty or have more items, as long as the first 3 exist.


at_least_3([_, _, _ | _]).

% at_most_3: True if the list has 0, 1, 2, or 3 elements.
% We define 4 separate facts. The engine will check them one by one.


at_most_3([]).
at_most_3([_]).
at_most_3([_, _]).
at_most_3([_, _, _]).


% Intersection


% intersect: True if L1 and L2 share at least one common element.
% We use the built-in member/2. If X is in L1, and that same X is in L2, they intersect.
intersect(L1, L2) :-
    member(X, L1),
    member(X, L2).

% all_intersect: True if L shares an element with EVERY list inside ListofLists.
% Base Case: An empty list of lists trivially succeeds.
all_intersect([], _).

% Recursive Case: L must intersect with the Head list, AND intersect with the Tail of the lists.
all_intersect([HeadList | TailLists], L) :-
    intersect(HeadList, L),
    all_intersect(TailLists, L).


% Source Removal (Topological Sort)


% HELPER: get_all_targets/2
% Extracts a master list of all nodes being pointed to (i.e., all items in all adjacency lists).


get_all_targets([], []).
get_all_targets([[_, Targets] | RestNodes], AllTargets) :-
    get_all_targets(RestNodes, RestTargets),
    append(Targets, RestTargets, AllTargets).

% source_removal: Performs topological sort by repeatedly removing nodes with an in-degree of 0.
% Base Case: An empty graph yields an empty sorted list.
source_removal([], []).



% Recursive Case:
source_removal(Graph, [Source | SortedRest]) :-
    % 1. Pick a candidate node from the graph. select/3 naturally removes it to create RemainingGraph.

    select([Source, _Edges], Graph, RemainingGraph),
    
    % 2. Gather every single target node present in the CURRENT graph.

    get_all_targets(Graph, AllTargets),
    
    % 3. Verify it is a Source: The candidate must NOT be in the targets list (\+ means NOT).

    \+ member(Source, AllTargets),
    
    % 4. Recurse. Because select/3 removed the Source and its edges, RemainingGraph is updated.
    
    source_removal(RemainingGraph, SortedRest).